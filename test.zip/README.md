file2bmp
========

save file to a bmp file, specially used for saving compressed tar/zip file to a bmp file.

The program is written in python, so you need install python before use it.

Usage
=====

For windows, double click the script and follow the prompt message.

For Unix/Linux, with a shell and type command "python file2bmp.py", then follow the prompt message.

Todo List
=========

- [ ] delete the test file
